<?php
class db{
 
    function OpenCon(){
        $conn = new mysqli("localhost","root","","doctorres");
        return $conn;
    }
    function insertUser($conn,$tablename,$fname,$lname,$password,$gender,$age,$department,$doctorposition,$email,$file,$number,$address){
        $sql="INSERT INTO $tablename(fname,lname,password,gender,age,department,doctorposition,email,file,number,address) VALUES
         ('$fname','$lname','$password','$gender',$age,'$department','$doctorposition','$email','$file','$number','$address')";
        
        if($conn->query($sql)===TRUE){
            echo "data inserted";
        }
        else{
            echo "Error occured".$conn->error;
        }
    }

    function CheckUser($conn,$tablename,$fname,$password){
        $sql = $conn->query("SELECT * FROM ". $tablename." WHERE fname='". $fname."' AND password='". $password."'");
        return $sql;
    }

    function ShowAll($conn,$tablename){
        $sql = $conn->query("SELECT * FROM  $tablename");
        return $sql;
    }

    
    function UpdateUser($conn,$table,$fname,$email)
    {
        $sql = "UPDATE $table SET name='$fname', number='$number' WHERE name='$fname'";

        if ($conn->query($sql) === TRUE) {
            $result= TRUE;
        } else {
            $result= FALSE ;
        }
        return  $result;
    }


    function CloseCon($conn){
        $conn -> close();
    }
}
?>