<div>

	<?php
		echo "<p> Copyright &copy; E- HEALTH SERVICE 2022";
	?>

</div>