
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=2">
	<title>Home</title>
</head>
<body align='center'>
	<h1>N-BANGLA HOSPITAL</h1>

	<h1> Health is the biggest wealth for a human being</h1>

<img src="../image/Doctor.jpg" alt="image" width="400" height="200">


	
	<p align='center'>
			  
			   <a href="Login.php">Login</a>|<br>
			   <a href="Doctor.php">Click for Registration </a><br>
			   <a href="patient.php">Click for Check up</a><br>
			   <a href="About.php">About us</a> <br>
			   <a href="Contact.php">Contact us</a>
			   <a href="update.php">update data</a>

			 

			   
			</p>
			
					
					
		
</body>
<div align="center">
		<?php include 'Footer.php';?>
	</div>
</html>

