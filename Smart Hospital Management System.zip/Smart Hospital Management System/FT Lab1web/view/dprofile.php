<?php
    echo '<h1>Welcome to your portal:Doctor</h1>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<img src="../image/welcome.jpg" alt="welcome" width="300" height="200">
<br> <br>

<a href="Home.php">Back to home</a><br>
<a href="Logout.php">Logout</a>


</body>
<div >
		<?php include 'Footer.php';?>
	</div>
</html>