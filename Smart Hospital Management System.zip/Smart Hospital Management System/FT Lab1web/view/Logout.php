<!DOCTYPE html>
<html lang="en">

<body>

 
<?php
    session_start();
    if(session_destroy()){
        header('Location: ../view/login.php');
    }
?>
 

 <p><a href="Home.php">Back to home</a></p>
</body>


</html>