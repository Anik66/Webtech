
<?php
session_start(); 

include('../control/updatecheck.php');


if(empty($_SESSION["username"])) // Destroying All Sessions
{
header("Location: ../control/Loginresult.php"); // Redirecting To Home Page
}

?>

<!DOCTYPE html>
<html>
<body>
<h2>Profile Page</h2>

welcome, <h3><?php echo $_SESSION["username"];?></h3>
<br> to Your Profile Page.
<br><br>
<?php
$radio1=$radio2=$radio3="";
$firstname=$email="";
$connection = new db();
$conobj=$connection->OpenCon();

$userQuery=$connection->CheckUser($conobj,"registration",$_SESSION["username"],$_SESSION["password"]);

if ($userQuery->num_rows > 0) {

    // output data of each row
    while($row = $userQuery->fetch_assoc()) {
      $firstname=$row["username"];
      $email=$row["email"];
     
      if(  $row["gender"]=="male" )
      { $radio1="checked"; }
      else if($row["gender"]=="female")
      { $radio2="checked"; }
      else{$radio3="checked";}

   
  } 
}
  else {
    echo "0 results";
  }



?>
<form action='' method='post'>
firstname : <input type='text' name='firstname' value="<?php echo $fname; ?>" >

email : <input type='text' name='email' value="<?php echo $email; ?>" >
 Gender:
     <input type='radio' name='gender' value='male'<?php echo $radio1; ?>>male
     <input type='radio' name='gender' value='female' <?php echo $radio2; ?> >feMale
     <input type='radio' name='gender' value='other'<?php  $radio3; ?> > Other

     <input name='update' type='submit' value='Update'>  

     <?php echo $error; ?>
<br>
<br>
<a href="../view/Login.php">Back </a>

<a href="../view/logout.php"> logout</a>

</body>
</html>
