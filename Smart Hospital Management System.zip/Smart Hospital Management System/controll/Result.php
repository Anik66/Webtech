<?php
include("../model/db.php");
$isValid=1;

if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["First-name"]=="")
    {
        echo " Firstname is required"; echo"<br>";
      
    }
    else{
        echo $_REQUEST["First-name"];echo"<br>";
        $isValid=1;
    }

    if($_REQUEST["Last-name"]=="")
      {
        echo " Lasttname is required";echo"<br>";
          
      }
    else{
        echo $_REQUEST["Last-name"];echo"<br>";
        $isValid=1;
    }
}


if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["password"]==" ")
    {
        echo "Password is required";echo"<br>";
    }
    elseif(strlen($_REQUEST["password"]) > 3){
        echo "Password must contain at least 3 characters";
    }
    else{
        echo $_REQUEST["password"];
        echo"<br>";
        $isValid=1;
    }
}


if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["Confirm-password"]=="")
    {
        echo "Confirm password is required";echo"<br>";
        
    }
    elseif($_REQUEST["Confirm-password"]==$_REQUEST["password"]){
        echo "Your password: ",$_REQUEST["Confirm-password"];
    }
    else{
        echo "Your password should be same";echo"<br>";
        $isValid=1;
    }
}

    
    
if(isset($_REQUEST["submit"]))
{
    if(isset($_REQUEST["gender"]))
    {
        if($_REQUEST["gender"]=="male")
        {
            echo "you have checked",$_REQUEST["gender"];
            echo"<br>";
        }
        else{
            echo "you have checked",$_REQUEST["gender"];
            echo"<br>";
        }
        $isValid=1;
    }
    else{
        echo "radio is not check";echo"<br>";
    }
}
  

if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["age"]=="")
    {
        echo " Doctor age is required";echo"<br>";
    }
    else{
        echo $_REQUEST["age"];echo"<br>";   
        $isValid=1; 
    }
}



if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["department"]=="")
    {
        echo " Department name is required";echo"<br>";
        
    }
    else{
        echo $_REQUEST["department"];echo"<br>";
        $isValid=1;
    }
}


if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["position"]=="")
    {
        echo " Doctor Position is required";echo"<br>";

    }
    else{
        echo $_REQUEST["position"];echo"<br>";
        $isValid=1;
    }
}



 
if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["email"]=="")
    {
        echo " Email Id is required";echo"<br>";
    
    }
    else{
        echo $_REQUEST["email"];echo"<br>";
        $isValid=1;
    }
}


if(isset($_REQUEST["submit"]))
{
    $target_dir = "../File/";
    $target_file = $target_dir . $_FILES["fileToUpload"]["name"];

    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". $_FILES["fileToUpload"]["name"]. " has been uploaded.";
        $fileupload = $_FILES["fileToUpload"]["type"];echo"<br>";
        $isValid=1;
    }
    else {
        echo "Sorry, there was an error uploading your file.";
    }
}


if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["number"]==" ")
    {
        echo "phone number is required";echo"<br>";
    }
    elseif(strlen($_REQUEST["password"]) > 11){
        echo "Phone number must contain at least 11 characters";
    }
    else{
        echo $_REQUEST["number"];
        echo"<br>";
        $isValid=1;
    }
}


if(isset($_REQUEST["submit"]))
{
    if($_REQUEST["address"]=="")
    {
        echo " Address is required";echo"<br>";
    }
    else{
        echo $_REQUEST["address"];echo"<br>";
        $isValid=1;
    }
}


if(isset($_REQUEST["submit"]))
{
    $checkboxvalue=array();
    $checkbox=0;
    if(isset($_REQUEST["Dhaka"]))
    {
        if($_REQUEST["Dhaka"]=="Dhaka"){
            echo "you clicked",$_REQUEST["Dhaka"];
            echo"<br>";
            $checkbox=1;
            array_push($checkboxvalue,$_REQUEST["Dhaka"]);
        }
        else{
            echo "not checked";
        }
    }
    
    if(isset($_REQUEST["Chittagong"]))
    {
        if($_REQUEST["Chittagong"]=="Chittagong"){
            echo "you clicked",$_REQUEST["Chittagong"];
            echo"<br>";
            $checkbox=1;
            array_push($checkboxvalue,$_REQUEST["Chittagong"]);
        }
    }
    
    if(isset($_REQUEST["Rajshahi"]))
    {
        if($_REQUEST["Rajshahi"]=="Rajshahi"){
            echo "you clicked",$_REQUEST["Rajshahi"];
            echo"<br>";
            $checkbox=1;
            array_push($checkboxvalue,$_REQUEST["Rajshahi"]);
        }
    }
    
    if(isset($_REQUEST["Khulna"]))
    {
        if($_REQUEST["Khulna"]=="Khulna"){
            echo "you clicked",$_REQUEST["Khulna"];
            echo"<br>";
            $checkbox=1;
            array_push($checkboxvalue,$_REQUEST["Khulna"]);
        }
    }

   if($checkbox==0){
        echo "checkbox is not checked";
        echo"<br>";
    }
    
    

    if($isValid==1){
        $mydb=new db();
        $conobj=$mydb->openCon();
        
        $mydb->insertUser($conobj,"registration",$_REQUEST["First-name"],$_REQUEST["Last-name"],$_REQUEST["password"],$_REQUEST['gender'],$_REQUEST['age'],$_REQUEST['department'],$_REQUEST['position'],$_REQUEST['email'],$fileupload,$_REQUEST['number'],$_REQUEST['address']);

        $mydb->CloseCon($conobj);
    }
}

?>